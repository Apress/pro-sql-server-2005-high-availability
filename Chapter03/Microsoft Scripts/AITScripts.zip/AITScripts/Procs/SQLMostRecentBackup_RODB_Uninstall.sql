use msdb
go

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[MostRecentBackup_RODB]') and OBJECTPROPERTY(id, N'IsView') = 1)
drop view [dbo].[MostRecentBackup_RODB]
GO