use msdb
go


if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[SQLBackupTranAll02]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[SQLBackupTranAll02]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[SQLBackupTranAll02XpResult]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table [dbo].[SQLBackupTranAll02XpResult]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[SQLBackupTranCommands]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table [dbo].[SQLBackupTranCommands]
GO

