use msdb
go
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[SQLSpecifyDBIndexDeFragExclusions]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[SQLSpecifyDBIndexDeFragExclusions]
GO


CREATE PROCEDURE SQLSpecifyDBIndexDeFragExclusions 
(@DbName1 sysname ='master'
,@DbName2 sysname ='master'
,@DbName3 sysname ='master'
,@DbName4 sysname ='master'
,@DbName5 sysname ='master'
,@DbName6 sysname ='master'
,@DbName7 sysname ='master'
,@DbName8 sysname ='master'
,@DbName9 sysname ='master'
,@DbName10 sysname ='master'
,@DbName11 sysname ='master'
,@DbName12 sysname ='master'
,@DbName13 sysname ='master'
,@DbName14 sysname ='master'
,@DbName15 sysname ='master'
,@DbName16 sysname ='master'
,@DbName17 sysname ='master'
,@DbName18 sysname ='master'
,@DbName19 sysname ='master'
,@DbName20 sysname ='master'
,@DbName21 sysname ='master'
,@DbName22 sysname ='master'
,@DbName23 sysname ='master'
,@DbName24 sysname ='master'
,@DbName25 sysname ='master'
,@DbName26 sysname ='master'
,@DbName27 sysname ='master'
,@DbName28 sysname ='master'
,@DbName29 sysname ='master'
,@DbName30 sysname ='master'
,@DbName31 sysname ='master'
,@DbName32 sysname ='master'
,@DbName33 sysname ='master'
,@DbName34 sysname ='master'
,@DbName35 sysname ='master'
,@DbName36 sysname ='master'
,@DbName37 sysname ='master'
,@DbName38 sysname ='master'
,@DbName39 sysname ='master'
,@DbName40 sysname ='master'
,@DbName41 sysname ='master'
,@DbName42 sysname ='master'
,@DbName43 sysname ='master'
,@DbName44 sysname ='master'
,@DbName45 sysname ='master'
,@DbName46 sysname ='master'
,@DbName47 sysname ='master'
,@DbName48 sysname ='master'
,@DbName49 sysname ='master'
,@DbName50 sysname ='master')
AS
----------------------------------------------------------------------------------------------
--  Author Mark G. Pohto / Microsoft SQL Operations 
----------------------------------------------------------------------------------------------
-- SQLSpecifyBackupExclusions msdb
-- Create a table to hold names of databases that are
-- to be excluded from SQL backups and DBCCs.
if exists (select * from dbo.sysobjects where id = object_id('SQLDBIndexDefragExclusions'))
BEGIN
  DROP TABLE msdb..SQLDBIndexDefragExclusions
END

CREATE TABLE msdb..SQLDBIndexDefragExclusions (name Sysname NOT NULL)

-- Insert specified databases supplied in arguments
-- into the backupexclusions table, validate the dbname
-- on sysdatabases and disallow exclusion of master.
INSERT INTO msdb..SQLDBIndexDefragExclusions
SELECT name 
FROM   master..sysdatabases 
WHERE  name in (@dbname1,@dbname2 ,@dbname3 ,@dbname4
               ,@dbname5,@dbname6 ,@dbname7 ,@dbname8
               ,@dbname9,@dbname10 ,@dbname11 ,@dbname12
               ,@dbname13,@dbname14 ,@dbname15 ,@dbname16
               ,@dbname17,@dbname18,@dbname19,@dbname20
               ,@dbname21,@dbname22 ,@dbname23 ,@dbname24
               ,@dbname25,@dbname26,@dbname27,@dbname28
               ,@dbname29,@dbname30,@dbname31,@dbname32 
		,@dbname33 ,@dbname34,@dbname35,@dbname36
		,@dbname37,@dbname38,@dbname39,@dbname40
		,@dbname41,@dbname42 ,@dbname43 ,@dbname44
               ,@dbname45,@dbname46,@dbname47,@dbname48
               ,@dbname49,@dbname50)

AND    name != 'master'

GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO
