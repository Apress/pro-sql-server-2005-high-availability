use msdb
go

IF EXISTS (SELECT * FROM DBO.SYSOBJECTS WHERE ID = OBJECT_ID(N'[DBO].[SQLBackupDiffAll01]') AND OBJECTPROPERTY(ID, N'ISPROCEDURE') = 1)
DROP PROCEDURE [DBO].[SQLBackupDiffAll01]
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO


create PROCEDURE SQLBackupDiffAll01 
 @compress      varchar(20)  = 'nocompress'
,@drive         varchar(255) = 'E:\SQL\BAK\DIFF'
,@desc          varchar(20)  = 'SQL Backup'
,@threads       varchar(20)  = '3'
,@priority      varchar(20)  = 0
,@latency       varchar(20)  = 0
,@init          varchar(20)  = 1


AS

DECLARE @jobId uniqueidentifier 
DECLARE @sql_job varchar(1000) 
----------------------------------------------------------------------------------------------
--  Author Mark G. Pohto / Microsoft SQL Operations
----------------------------------------------------------------------------------------------
----------------------------------------------------------------------------------------------
-- This procedure Goes through every non READONLY database on the server
--  if a dump device does not exist it creates one (when using native SQL backups)
--  then it prepares the backup and verify commands using SQL syntax or using 
--  SQLLiteSpeed syntax. 
--
-- SQLBackupDiffAll02 processes backup commands that were created in this proc.
--
-- Databases listed in the BackupExclusions table are skipped
--
-- If the compress parameter is specified this process will use SQLLiteSpeed backup compression,
--    otherwise it will use a standard SQL backup command.
--
--  Parmeters:
--     @compress (default=nocompress)  
--         Causes procedure to use SQLLiteSpeed compression or Standard SQL BAckup
--     @drive (default=E)
--         Specifies which drive and path (e.g. e:\sql\bak\diff) backups will be placed on.
--     @desc (default=SQL Backup)
--         SQLLIteSpeed description to be stored with the backup.
--     @threads (default=3) Valid values 1,2,3 or 0.
--         Determines the number of threads used for the backup. 
--         Best results have been identified at 2-3 for a multi processor server. 
--         Use n-1 threads, for n processor server.
--     @priority (default=0) Valid values 1,2,3 or 0.
--         Enables the priority of a SQLLiteSpeed backup to be increased to 1, 2 or 3
--         This setting could impact other processes so the default is zero.
--     @latency (default=0) Valid Levels 0 through to 30.
--         This value is used to determine what latency level 
--         will be used for the backup. This command will slow down the backup and in effect 
--         reduce the CPU and I/O levels of the backup
--     @init (default=1) Valid values 1 or 0.
--         Used for SQLLIteSpeed backups to force backup file initialization, if value is set to 0
--         backups will be appended.
--
--    NOTE ABOUT ERROR CHECKING EXTENDED STORED PROCEDURES
--      Since an XP cannot be executed from within a string and still return a
--      valid error message, we have to format the string to load the return code
--      into a table (SQLBackupDiffAll02XpResult) for reference by calling proc (SQLBackupDiffAll02).
---------------------------------------------------------------------------------------------------
SET QUOTED_IDENTIFIER ON 
SET ANSI_NULLS ON 
DECLARE @DBName	   VARCHAR(100)
       ,@SQLString VARCHAR(2000)
DECLARE @XSQLSTring varchar (2000)
       ,@BackupPath varchar(255)
       ,@rc         int

set quoted_identifier off

-- This table will hold all commands for execution by SQLBackupDiffAll02
if exists (select * from dbo.sysobjects 
  where id = object_id(N'[dbo].[SQLBackupDiffCommands]') 
and OBJECTPROPERTY(id, N'IsUserTable') = 1)
  drop table [dbo].[SQLBackupDiffCommands]
CREATE TABLE dbo.SQLBackupDiffCommands 
   (backupCommandSeq  int   
   ,backupCommand     varchar(2000) NULL) 


Create table #NewBackupStandardPath
   (FileExists        int
  , FileIsDir         int
  , ParentDirExists   int)

-- check for backup path
SELECT @XSQLSTring = 'master..xp_fileexist "'+@drive+'"'
INSERT #NewBackupStandardPath EXEC  (@XSQLString)

--    set backup path variable
SELECT @BackupPath = @drive + '\'

--Now check the BackupStandardPath and create the folder
-- specifed by the user.

If (select ParentDirExists + FileIsDir 
    from #NewBackupStandardPath) != 2

BEGIN

	SET @sql_job='md ' + @drive

	EXEC msdb.dbo.sp_add_job @job_name = 'SQLBackupDiffAll01MakeDir' ,
		  		      @enabled  = 1, 
		  		      @start_step_id = 1, 
				      @owner_login_name='sa',
		  		      @job_id = @jobId OUTPUT 
	
	EXEC msdb.dbo.sp_add_jobstep @job_id = @jobId, 
			     		@step_name = 'Create Backup Folder', 
	 	  		     	@step_id = 1, 
			     		@subsystem = 'CMDEXEC', 
			     		@command = @sql_job 
	
	EXEC msdb.dbo.sp_add_jobserver @job_id = @jobId
	
	EXEC msdb.dbo.sp_start_job @job_id = @jobId,@output_flag=0 

END



DECLARE DB_Cursor CURSOR
FOR

select a.name
from   master..sysdatabases a
where  isnull(databaseproperty(a.name,'isReadOnly'),0) = 0
and    isnull(databaseproperty(a.name,'isOffline'),0)  = 0
and    isnull(databaseproperty(a.name,'IsSuspect'),0)  = 0
and    isnull(databaseproperty(a.name,'IsShutDown'),0)  = 0
and    isnull(databaseproperty(a.name,'IsNotRecovered'),0)  = 0
and    isnull(databaseproperty(a.name,'IsInStandBy'),0)  = 0
and    isnull(databaseproperty(a.name,'IsInRecovery'),0)  = 0
and    isnull(databaseproperty(a.name,'IsInLoad'),0)  = 0
and    isnull(databaseproperty(a.name,'IsEmergencyMode'),0)  = 0
and    isnull(databaseproperty(a.name,'IsDetached'),0)  = 0
and    name not in('tempdb')
and    not exists
  (select b.name
   from   msdb..SQLDBExclusions b
   where  a.name = b.name)
   
OPEN DB_Cursor

FETCH NEXT 
FROM DB_Cursor 
INTO @DBName 

-- Loop through all databases that should be backed up
-- and format the backup and verify commands using native 
-- SQL syntax or SQLLiteSpeed syntax.   
WHILE (@@FETCH_STATUS <> -1)
BEGIN
   IF (@@FETCH_STATUS <> -2)
   BEGIN 
     Select @SQLString = null

     -- If this is the master db, use standard backup only 
     --  otherwise use whatever the input parm @compress specifies
     IF NOT EXISTS (select * from master..sysdevices where name = @DBName+'_Diff_dump')
      and @DBName = 'master'
     BEGIN
        SELECT @SQLString = 'PRINT '+"'Creating Dump Device for DB: "+@DBName+ "'"+';'
        SELECT @SQLString = @SQLString+'EXEC sp_addumpdevice "disk", "'
           +@DBName+'_Diff_dump", "'+@BackupPath+@DBName+'_Diff.BAK"'
        insert into msdb..SQLBackupDiffCommands values  (10,@SQLString)
     END
     ELSE    
     IF NOT EXISTS (select * from master..sysdevices where name = @DBName+'_Diff_dump')
      and @compress != 'compress' 
     BEGIN
        SELECT @SQLString = 'PRINT '+"'Creating Dump Device for DB: "+@DBName+ "'"+';'
        SELECT @SQLString = @SQLString+'EXEC sp_addumpdevice "disk", "'
           +@DBName+'_Diff_dump", "'+@BackupPath+@DBName+'_Diff.BAK"'
        insert into msdb..SQLBackupDiffCommands values  (10,@SQLString)
     END
  
     IF @compress != 'compress' or @DBName = 'master'
     -- Prepare native SQL commands
     begin
         SELECT @SQLString = 'PRINT '+"'Backing Up DB: "+@DBName+ "'"+';'
         SELECT @SQLString = @SQLString+'BACKUP DATABASE ['+@DBName+'] TO ['+@DBName+'_Diff_DUMP] WITH INIT, STATS'
         insert into msdb..SQLBackupDiffCommands values  (20,@SQLString)

         -- Prepare VERIFYONLY command
         SELECT @SQLString = 'PRINT '+"'Verifying DB: "+@DBName+ "'"+';'
         SELECT @SQLString = @SQLString + 'restore verifyonly from disk= '
               + "'"+ @BackupPath +@DBName+ "_Diff.bak'"
         insert into msdb..SQLBackupDiffCommands values  (30,@SQLString)

     END
     ELSE
     -- Prepare SQLLiteSpeed commands
     begin
         SELECT @SQLString = 'PRINT '+"'Backing Up DB: "+@DBName+ "'"+';'
         SELECT @SQLString = @SQLString+'declare @rc int;exec @rc = master..xp_backup_database @database = ['+@DBName +']'
                + ", @filename = '" 
                      +@BackupPath 
                      +@DBName+ "_Diff.lsb'"
                + ", @desc = '" 
                      +@desc + "'"
                + ", @init = " 
                      +@init 
                + ", @threads = " 
                      +@threads  
                + ", @priority = " 
                      +@priority  
                + ", @with = 'differential'"         
                + ';insert into SQLBackupDiffAll02XpResult values (@rc)'
        
        insert into msdb..SQLBackupDiffCommands values  (20,@SQLString)

        -- Prepare VERIFYONLY command
        SELECT @SQLString = 'PRINT '+"'Verifying DB: "+@DBName+ "'"+';'
        SELECT @SQLString = @SQLString + 'declare @rc int;exec @rc = master..xp_restore_verifyonly @filename = '
              + "'"+ @BackupPath +@DBName+ "_Diff.lsb'"
              + ';insert into SQLBackupDiffAll02XpResult values (@rc)'
        insert into msdb..SQLBackupDiffCommands values  (30,@SQLString)
     END
   END
   FETCH NEXT 
   FROM DB_Cursor 
   INTO @DBName     
END
CLOSE      DB_Cursor
DEALLOCATE DB_Cursor


--delete the job.

WAITFOR DELAY  '000:00:05'

IF EXISTS (SELECT NAME FROM msdb.dbo.sysjobs WHERE Name='SQLBackupDiffAll01MakeDir')
BEGIN
	 EXEC msdb.dbo.sp_delete_job @job_name = 'SQLBackupDiffAll01MakeDir'


END





GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO








