use msdb
go

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

IF EXISTS (SELECT * FROM DBO.SYSOBJECTS WHERE ID = OBJECT_ID(N'[DBO].[SQLBackupDiffAll02]') AND OBJECTPROPERTY(ID, N'ISPROCEDURE') = 1)
DROP PROCEDURE [DBO].[SQLBackupDiffAll02]
GO

create PROCEDURE SQLBackupDiffAll02 
AS
----------------------------------------------------------------------------------------------
--  Author Mark G. Pohto / Microsoft SQL Operations
----------------------------------------------------------------------------------------------
-------------------------------------------------------------------------------------
--  This procedure processes backup/verify commands that were
--  prepared in SQLBackupDiffAll01.
-------------------------------------------------------------------------------------

declare @SQLCommand    varchar(2000)
       ,@SQLCommandSeq int
       ,@rc            int
       ,@LSrc          int
       ,@SQLrc         int

exec sp_update_job @job_name = '_SQL_BackupTranAll',@enabled = 0

-- this table holds the result of extended stored procedure execution
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[SQLBackupDiffAll02XpResult]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
begin
  drop table [dbo].[SQLBackupDiffAll02XpResult]
end
create table SQLBackupDiffAll02XpResult (xpresult int)


DECLARE SQLCommand_Cursor CURSOR
FOR
select backupCommandSeq,backupCommand 
from msdb..SQLBackupDiffCommands
order by backupCommandSeq


OPEN SQLCommand_Cursor

FETCH NEXT 
FROM SQLCommand_Cursor 
INTO @SQLCommandSeq 
    ,@SQLCommand

-- Cursor through the commands, execute them, remove them from
-- table if executed successfully.   
WHILE (@@FETCH_STATUS <> -1)
BEGIN
   IF (@@FETCH_STATUS <> -2)
   BEGIN 
      DELETE FROM SQLBackupDiffAll02XpResult
      EXEC (@SQLCommand)
      SELECT @SQLrc = @@error
      SELECT @LSrc  = max(xpresult) from SQLBackupDiffAll02XpResult
      --PRINT @SQLCommand
      -- check return code from standard operation or extended proc
      IF @SQLrc = 0
      AND ISNULL((select max(xpresult) from SQLBackupDiffAll02XpResult),0) = 0
      BEGIN
         delete from msdb..SQLBackupDiffCommands
         where backupCommand = @SQLCommand
      END
      
   END
   FETCH NEXT 
   FROM SQLCommand_Cursor 
   INTO @SQLCommandSeq
       ,@SQLCommand     
END
CLOSE      SQLCommand_Cursor
DEALLOCATE SQLCommand_Cursor


exec sp_update_job @job_name = '_SQL_BackupTranAll',@enabled = 1



GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

