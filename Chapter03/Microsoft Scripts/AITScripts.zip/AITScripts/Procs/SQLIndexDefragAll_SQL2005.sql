/**************************************************************************************
 Purpose	:  The Purpose of this Stored Procedure is to defrag Indexes in SQL 2005 user databases.
	                      
Created by	: RITS Platform Engineering Team 
		  (Meher Malakapalli and Manoharan Mariappan)

Date Created	: May 17, 2006

Modification History:
Date          	Who              What

=============  ===============  ====================================      
*/


USE [msdb]
GO

/****** Object:  StoredProcedure [dbo].[SQLIndexDefragAll_SQL2005]    Script Date: 07/14/2006 13:53:01 ******/


if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[SQLIndexDefragAll_SQL2005]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[SQLIndexDefragAll_SQL2005]
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO


CREATE PROCEDURE [dbo].[SQLIndexDefragAll_SQL2005]
				@DBName VARCHAR(80)=NULL,
				@TableName VARCHAR(100)=NULL,
				@frag float=10.0


AS

SET NOCOUNT ON



DECLARE @objectid int
DECLARE @indexid int
DECLARE @partitioncount bigint
DECLARE @schemaname sysname
DECLARE @objectname sysname
DECLARE @indexname sysname
DECLARE @partitionnum bigint
DECLARE @partitions bigint
DECLARE @DB_id INT
DECLARE @StrSQL NVARCHAR(400)
DECLARE @UpdSQL NVARCHAR(400)
DECLARE @command varchar(200)
DECLARE @sDbname VARCHAR(80)
DECLARE @OuterLoop INT
DECLARE @InnerLoop INT
DECLARE @databaseName VARCHAR(80)


--SET @dbName='AdventureWorks'

--Create a table to store databaseNames.
CREATE TABLE #TempDBList
             (DBName VARCHAR(80),
              Process INT DEFAULT 0
	          )

CREATE TABLE #Tempobjects
			 (DatabaseName VARCHAR(80),
			  objectID INT,
			  ObjectName VARCHAR(80),
			  SchemaName VARCHAR(60)
			  )

CREATE TABLE #TempIndexes
			 (DatabaseName VARCHAR(80),
			  objectID INT,
			  IndexID INT,
			  IndexName VARCHAR(100)
			  )

CREATE TABLE #TempPartitions
			 (DatabaseName VARCHAR(80),
			  objectID INT,
			  IndexID INT,
			  PartitionID BIGINT,
			  partitioncount BIGINT
			  )

CREATE TABLE #TableList 
			(Tabname VARCHAR(80))


CREATE TABLE #work_to_do
			(DatabaseName VARCHAR(80),
			 objectid int NULL,
		     	 objectName VARCHAR(80),
			 SchemaName VARCHAR(60),
			 indexid  int NULL,
			 PartitionID BIGINT,
			 IndexName VARCHAR(100),
			 partitionnum int NULL,
			 partitioncount bigint,
			 frag float NULL,
			 Status INT Default 0
			) 

IF @DBName IS NULL
BEGIN

	INSERT INTO #TempDBList(DBName) 
	SELECT [NAME] AS DBName FROM master.dbo.sysdatabases AS A
	WHERE [NAME] NOT IN ('master','msdb','tempdb','model','pubs')
	AND status &512 = 0
	AND   isnull(databaseproperty(a.name,'isReadOnly'),0) = 0
	AND    isnull(databaseproperty(a.name,'isOffline'),0)  = 0
	AND    isnull(databaseproperty(a.name,'IsSuspect'),0)  = 0
	AND    isnull(databaseproperty(a.name,'IsShutDown'),0)  = 0
	AND    isnull(databaseproperty(a.name,'IsNotRecovered'),0)  = 0
	AND    isnull(databaseproperty(a.name,'IsInStandBy'),0)  = 0
	AND    isnull(databaseproperty(a.name,'IsInRecovery'),0)  = 0
	AND    isnull(databaseproperty(a.name,'IsInLoad'),0)  = 0
	AND    isnull(databaseproperty(a.name,'IsEmergencyMode'),0)  = 0
	AND    isnull(databaseproperty(a.name,'IsDetached'),0)  = 0
	AND NOT EXISTS (SELECT B.[NAME]
   		     FROM msdb..SQLDBIndexDefragExclusions b
  		     WHERE A.[NAME] = b.[NAME])
	ORDER BY [Name] ASC

END

ELSE
BEGIN

	INSERT INTO #TempDBList(DBName) 
	SELECT [NAME] AS DBName FROM master.dbo.sysdatabases AS A
	WHERE [NAME] NOT IN ('master','msdb','tempdb','model','pubs')
	AND status &512 = 0
	AND   isnull(databaseproperty(a.name,'isReadOnly'),0) = 0
	AND    isnull(databaseproperty(a.name,'isOffline'),0)  = 0
	AND    isnull(databaseproperty(a.name,'IsSuspect'),0)  = 0
	AND    isnull(databaseproperty(a.name,'IsShutDown'),0)  = 0
	AND    isnull(databaseproperty(a.name,'IsNotRecovered'),0)  = 0
	AND    isnull(databaseproperty(a.name,'IsInStandBy'),0)  = 0
	AND    isnull(databaseproperty(a.name,'IsInRecovery'),0)  = 0
	AND    isnull(databaseproperty(a.name,'IsInLoad'),0)  = 0
	AND    isnull(databaseproperty(a.name,'IsEmergencyMode'),0)  = 0
	AND    isnull(databaseproperty(a.name,'IsDetached'),0)  = 0
	AND [Name]=@DBName

END



--Loop over the databases
DECLARE DBCursor CURSOR
FOR SELECT DBNAME
        FROM #TempDBList
       WHERE Process=0
	   ORDER BY DBNAME ASC

OPEN DBCursor

FETCH DBCursor INTO @sDbname 

--Save the fetch status to a variable
SELECT @OuterLoop = @@FETCH_STATUS

WHILE @OuterLoop = 0
BEGIN

		

-- Conditionally select tables and indexes from the sys.dm_db_index_physical_stats function 
-- and convert object and index IDs to names.

--Get the DBID

SET @db_id = DB_ID(@sDbname)


SELECT @StrSQL = N'SELECT'+' ''' +@sDbName+''' AS DatabaseName'+ ','+'soj.object_id, QUOTENAME'+'('+'sc.[Name]'+')'+'AS SchemaName,'+
		         'QUOTENAME'+'('+ 'soj.[Name])AS objectName FROM '+ QuoteName(@sDbName) 
		         +'.'+'sys.objects soj JOIN '+QuoteName(@sDbName)+'.'+
                 'sys.schemas sc ON soj.schema_id=sc.schema_id WHERE [type] = ''U'''      

INSERT INTO #Tempobjects(DatabaseName,
			 objectid,
			 SchemaName,
			 ObjectName
			 )

EXEC sp_executesql @StrSQL




INSERT INTO #work_to_do 
		(DatabaseName,
		 objectID,
		 IndexID,
	     	 PartitionID,
	         Partitionnum,
		 Frag
		 )
SELECT
    DB_NAME(@db_id) AS DatabaseName,
    object_id AS objectid,
    index_id AS indexid,
	NULL AS PartitionID,
    partition_number AS partitionnum,
    avg_fragmentation_in_percent AS frag
FROM sys.dm_db_index_physical_stats (@db_id, NULL, NULL , NULL, 'LIMITED')
WHERE avg_fragmentation_in_percent > @Frag AND index_id > 0


IF (SELECT COUNT(DISTINCT DatabaseName) FROM #work_to_do
	 WHERE DatabaseName=@sDbname) = 0
BEGIN
		PRINT ''
		PRINT 'Indexing in Database: ' + @sDbname
		PRINT '___________________________________'
		PRINT 'Re indexing for tables not needed in this Database. Fragmentation levels ok.'
		PRINT ''
END

ELSE
BEGIN
		PRINT ''
		PRINT 'Indexing in Database: ' + @sDbname
		PRINT '___________________________________'
		PRINT ''
END

SELECT @StrSQL= N'SELECT '+' ''' +@sDbName+''' AS DatabaseName'+ ','+ 'si.name, si.object_id,si.Index_ID
  				 FROM ' + QuoteName(@sDbName)+'.'+'sys.indexes si INNER JOIN #work_to_do W' +
				 ' ON  si.object_id = W.objectid' +
				 ' AND si.index_id = W.indexid '  +
				 ' AND EXISTS (SELECT DatabaseName FROM #work_to_do WHERE DatabaseName='+' ''' +@sDbName+''')'

INSERT INTO #TempIndexes 
			(DatabaseName,
			 IndexName,
			 objectID,
			 IndexID)

EXEC sp_executesql @StrSQL

SELECT @StrSQL= N'SELECT '+' ''' +@sDbName+''' AS DatabaseName'+','+'count (*) AS Partitioncount ' +','+
				 'spi.object_id, spi.index_id  
				  FROM ' + QuoteName(@sDbName)+'.'+' sys.partitions spi INNER JOIN #work_to_do W' +
				 ' ON  spi.object_id = W.objectid' +
				 ' AND spi.index_id = W.indexid' +
				 ' GROUP BY spi.object_ID,spi.index_id' 


INSERT INTO #TempPartitions
			(DatabaseName,
			 partitioncount,
			 objectID,
			 IndexID
			 )

EXEC sp_executesql @StrSQL
			  

--Update ObjectName and SchemaName
UPDATE W
SET W.ObjectName=T.objectName,
	W.SchemaName=T.SchemaName
FROM #work_to_do W,
     #Tempobjects T
WHERE W.DatabaseName=T.DatabaseName
AND   T.DatabaseName=@sDbName
AND W.objectid=T.objectID

--Update the IndexName
UPDATE W
SET W.IndexName=T.IndexName
FROM #work_to_do W,
	 #TempIndexes T
WHERE W.DatabaseName=T.DatabaseName
AND   T.DatabaseName=@sDbName
AND   W.objectid=T.objectID
AND   W.IndexID = T.IndexID



--Update the PartitionCount

UPDATE W
SET W.Partitioncount=T.partitioncount
FROM #work_to_do W,
     #TempPartitions T
WHERE W.DatabaseName=T.DatabaseName
AND   T.DatabaseName=@sDbName
AND   W.objectid=T.objectID
AND   W.IndexID = T.IndexID


--Select * from #Work_to_do


-- Declare the cursor for the list of partitions to be processed.
IF @TableName IS NULL
BEGIN
		DECLARE partitions CURSOR 
		FOR 
		SELECT DatabaseName,
			   objectID,
			   objectName,
			   SchemaName,
			   indexID,
			   indexName,
			   Partitionnum,
			   partitioncount,
			   frag
		FROM   #work_to_do
		WHERE Status=0
		ORDER BY DatabaseName ASC
END
ELSE
	BEGIN

			INSERT INTO #TableList (Tabname)
			SELECT TABLENAME
			FROM dbo.fnCSV_To_Table(@TableName)

		DECLARE partitions CURSOR 
		FOR 
		SELECT DatabaseName,
			   objectID,
			   objectName,
			   SchemaName,
			   indexID,
			   indexName,
			   Partitionnum,
			   partitioncount,
			   frag
		FROM   #work_to_do
		WHERE Status=0
		AND  objectName IN 
					(SELECT QUOTENAME(TabName) FROM #TableList)
		ORDER BY DatabaseName ASC

	END

-- Open the cursor.
OPEN partitions

-- Loop through the partitions.
FETCH NEXT
   FROM partitions
   INTO @databaseName,
		@objectid, 
		@objectName,
		@schemaname,
		@indexid, 
		@indexName,
		@partitionnum, 
		@partitioncount,
		@frag





WHILE @@FETCH_STATUS = 0
    BEGIN

	

	PRINT ''
	SELECT @command = 'ALTER INDEX ' + QuoteName(@indexname) + ' ON ' + QuoteName(@databaseName) + '.' + @schemaname + '.' + @objectname + ' REORGANIZE';
		
	IF @partitioncount > 1
	 BEGIN
	      SELECT @command = @command + ' PARTITION=' + CONVERT (CHAR, @partitionnum);
	 END

	
	EXEC (@command);
    


	PRINT 'Executed ' + @command + ' Successfully.';

				UPDATE #work_to_do
				SET Status=1
				WHERE DatabaseName=@databaseName

FETCH NEXT 
FROM partitions 
INTO @databaseName,@objectid, @objectName,@schemaName,@indexid, @indexName,@partitionnum,@partitioncount, @frag
END
-- Close and deallocate the cursor.
CLOSE partitions
DEALLOCATE partitions

--Update the processed database status
	 UPDATE #TempDBList 
	 SET Process = 1
	 WHERE DBName = @sDbname  

	 DELETE FROM #TempDBList 
	 WHERE Process=1
	 AND DBName=@sdbName

    --Fetch next database
    --PRINT 'Fetching the next database'

    FETCH DBCursor into @sDbname


    SELECT @OuterLoop = @@FETCH_STATUS

END

CLOSE DBCursor
DEALLOCATE DBCursor

-- Drop the temporary table

DROP TABLE #work_to_do
DROP TABLE #TempDBList
DROP TABLE #Tempobjects
DROP TABLE #TempIndexes
DROP TABLE #TempPartitions
DROP TABLE #TableList






