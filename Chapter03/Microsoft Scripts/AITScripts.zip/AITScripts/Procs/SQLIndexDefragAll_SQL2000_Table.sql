USE MSDB
GO


if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[SQLIndexDefragCommands]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table [dbo].[SQLIndexDefragCommands]
GO

CREATE TABLE [dbo].[SQLIndexDefragCommands] (
	[DBName] [varchar] (80) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[DefragCommand] [varchar] (2000) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[Process] [int] DEFAULT 0
) ON [PRIMARY]
GO

