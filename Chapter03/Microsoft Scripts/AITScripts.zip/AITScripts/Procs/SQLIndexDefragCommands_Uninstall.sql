use msdb
go

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[SQLIndexDefragCommands]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table [dbo].[SQLIndexDefragCommands]
GO



