use msdb
go
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[MostRecentBackup_RODB]') and OBJECTPROPERTY(id, N'IsView') = 1)
drop view [dbo].[MostRecentBackup_RODB]
GO
----------------------------------------------------------------------------------------------
--  Author Gouri Vaddi / Microsoft SQL Operations 
----------------------------------------------------------------------------------------------



-- create view with most recent backup for non read only databases
CREATE VIEW MostRecentBackup_RODB
AS
select   a.database_name as 'DatabaseName', max(backup_finish_date) as 'BackupDate'
from     msdb..backupset a
where    a.type in ('I','D')
and exists 
  (select *
   from   master..sysdatabases b
   where  a.database_name = b.name
   and    isnull(databaseproperty(b.name,'isOffline'),0)  = 0)
and not exists
  (select * 
   from SQLDBExclusions c
   where a.database_name = c.name)
group by a.database_name


GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

