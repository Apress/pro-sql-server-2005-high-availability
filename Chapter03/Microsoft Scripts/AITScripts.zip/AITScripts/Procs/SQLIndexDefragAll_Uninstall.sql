use msdb
go

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[SQLIndexDefragAll_SQL2000]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[SQLIndexDefragAll_SQL2000]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[SQLIndexDefragAll_SQL2005]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[SQLIndexDefragAll_SQL2005]
GO


if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[SQLIndexDefragAll]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[SQLIndexDefragAll]
GO

