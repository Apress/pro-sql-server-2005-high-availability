use msdb
go


IF EXISTS (SELECT * FROM DBO.SYSOBJECTS WHERE ID = OBJECT_ID(N'[DBO].[SQLBackupAll02]') AND OBJECTPROPERTY(ID, N'ISPROCEDURE') = 1)
DROP PROCEDURE [DBO].[SQLBackupAll02]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[SQLBackupAll02XpResult]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table [dbo].[SQLBackupAll02XpResult]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[SQLBackupCommands]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table [dbo].[SQLBackupCommands]
GO

