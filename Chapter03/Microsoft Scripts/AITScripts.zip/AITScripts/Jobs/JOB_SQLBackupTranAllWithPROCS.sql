
use msdb
go
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[SQLBackupTranAll01]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[SQLBackupTranAll01]
GO


CREATE PROCEDURE SQLBackupTranAll01 
AS
--  This proc is paired with SQLBackupTranAll02 (this job creates commands, 02 executes them)
-- This procedure Goes through every non READONLY non excluded database on the server
--  if a TRAN dump device does not exist it creates one (as long as the standard path is available)
--  then it runs a TRan backup.  If the last backup completed was a full backup, then the log 
--  dump device is initialized.
-- Databases listed in the BackupExclusions table are skipped

SET QUOTED_IDENTIFIER ON 
SET ANSI_NULLS ON 
DECLARE @DBName	   VARCHAR(100)
       ,@SQLString VARCHAR(255)
       ,@INIT      CHAR(6)



if exists (select * from msdb.dbo.sysobjects 
     where id = object_id(N'SQLBackupTranCommands') 
     and OBJECTPROPERTY(id, N'IsUserTable') = 1)
  drop table [SQLBackupTranCommands]


CREATE TABLE msdb.dbo.SQLBackupTranCommands 
(backupCommandSeq  int   
,backupCommand     varchar(255) NULL
) 


DECLARE DB_Cursor CURSOR
FOR

select a.name
from   master..sysdatabases a
where  databaseproperty(a.name,'isReadOnly') = 0
and    databaseproperty(a.name,'isOffline') = 0
and    databaseproperty(a.name,'IsTruncLog') = 0
and    name != 'tempdb'
and    not exists
  (select b.name
   from   msdb..SQLDBExclusions b
   where  a.name = b.name)
   
OPEN DB_Cursor

FETCH NEXT 
FROM DB_Cursor 
INTO @DBName 
   
WHILE (@@FETCH_STATUS <> -1)
BEGIN
   IF (@@FETCH_STATUS <> -2)
   BEGIN 
     -- Get the Tran log INIT or NOINIT option based on 
     --  what kind of backup was completed last.
     select @INIT =  CASE type 
                WHEN 'D' 
                  then 'INIT' 
                ELSE null 
                END 
     from msdb..backupset 
     where backup_finish_date = 
          (select max(backup_finish_date) 
           from msdb..backupset 
           where database_name = @DBName)
     and   database_name = @DBName
     and   Type = 'D'

     -- Add Tran dump device if it does not exist 
     IF NOT EXISTS (select * from master..sysdevices where name = @DBName+'_Tran')
       BEGIN
         SELECT @SQLString = 'EXEC sp_addumpdevice "disk", "'
            +@DBName+'_TRAN", "f:\sql\tran\'+@DBName+'_Tran.BAK"'
         insert into msdb..SQLBackupTranCommands values  (1,@SQLString)
       END

     -- Backup database to standard dump device
     SELECT @SQLString = 'BACKUP TRAN '+@DBName+' TO '+@DBName+'_TRAN WITH STATS,'+IsNull(@INIT,'NOINIT')
     --print @SQLString
     insert into msdb..SQLBackupTranCommands values  (2,@SQLString)
   END
   FETCH NEXT 
   FROM DB_Cursor 
   INTO @DBName     
END
CLOSE      DB_Cursor
DEALLOCATE DB_Cursor



GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO
use msdb
go
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

IF EXISTS (SELECT * FROM DBO.SYSOBJECTS WHERE ID = OBJECT_ID(N'[DBO].[SQLBackupTranAll02]') AND OBJECTPROPERTY(ID, N'ISPROCEDURE') = 1)
DROP PROCEDURE [DBO].[SQLBackupTranAll02]
GO

CREATE PROCEDURE SQLBackupTranAll02 
AS


declare @SQLCommand    varchar(255)
       ,@SQLCommandSeq int

DECLARE SQLCommand_Cursor CURSOR
FOR
select backupCommandSeq,backupCommand 
from msdb..SQLBackupTranCommands
order by backupCommandSeq


OPEN SQLCommand_Cursor

FETCH NEXT 
FROM SQLCommand_Cursor 
INTO @SQLCommandSeq 
    ,@SQLCommand
   
WHILE (@@FETCH_STATUS <> -1)
BEGIN
   IF (@@FETCH_STATUS <> -2)
   BEGIN 
      PRINT @SQLCommand
      EXEC (@SQLCommand)
      --PRINT @SQLCommand
      IF @@ERROR = 0
      BEGIN
         delete from msdb..SQLBackupTranCommands
         where backupCommand = @SQLCommand
      END

   END
   FETCH NEXT 
   FROM SQLCommand_Cursor 
   INTO @SQLCommandSeq
       ,@SQLCommand     
END
CLOSE      SQLCommand_Cursor
DEALLOCATE SQLCommand_Cursor


GO

-- Script generated on 3/7/2002 2:26 PM
-- By: REDMOND\mpohto
-- Server: SQLSQL1

BEGIN TRANSACTION            
  DECLARE @JobID BINARY(16)  
  DECLARE @ReturnCode INT    
  SELECT @ReturnCode = 0     
IF (SELECT COUNT(*) FROM msdb.dbo.syscategories WHERE name = N'Database Maintenance') < 1 
  EXECUTE msdb.dbo.sp_add_category @name = N'Database Maintenance'

  -- Delete the job with the same name (if it exists)
  SELECT @JobID = job_id     
  FROM   msdb.dbo.sysjobs    
  WHERE (name = N'SQLBackupTranAll')       
  IF (@JobID IS NOT NULL)    
  BEGIN  
  -- Check if the job is a multi-server job  
  IF (EXISTS (SELECT  * 
              FROM    msdb.dbo.sysjobservers 
              WHERE   (job_id = @JobID) AND (server_id <> 0))) 
  BEGIN 
    -- There is, so abort the script 
    RAISERROR (N'Unable to import job ''SQLBackupTranAll'' since there is already a multi-server job with this name.', 16, 1) 
    GOTO QuitWithRollback  
  END 
  ELSE 
    -- Delete the [local] job 
    EXECUTE msdb.dbo.sp_delete_job @job_name = N'SQLBackupTranAll' 
    SELECT @JobID = NULL
  END 

BEGIN 

  -- Add the job
  EXECUTE @ReturnCode = msdb.dbo.sp_add_job @job_id = @JobID OUTPUT , @job_name = N'SQLBackupTranAll', @owner_login_name = N'sa', @description = N'No description available.', @category_name = N'Database Maintenance', @enabled = 1, @notify_level_email = 0, @notify_level_page = 0, @notify_level_netsend = 0, @notify_level_eventlog = 2, @delete_level= 0
  IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback 

  -- Add the job steps
  EXECUTE @ReturnCode = msdb.dbo.sp_add_jobstep @job_id = @JobID, @step_id = 1, @step_name = N'SQLBackupTranAll01', @command = N'EXEC msdb..SQLBackupTranAll01', @database_name = N'master', @server = N'', @database_user_name = N'', @subsystem = N'TSQL', @cmdexec_success_code = 0, @flags = 0, @retry_attempts = 0, @retry_interval = 1, @output_file_name = N'e:\sql\bak\SQLBackupTranAllLog.txt', @on_success_step_id = 0, @on_success_action = 3, @on_fail_step_id = 0, @on_fail_action = 2
  IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback 
  EXECUTE @ReturnCode = msdb.dbo.sp_add_jobstep @job_id = @JobID, @step_id = 2, @step_name = N'SQLBackupTranAll02 (with retry)', @command = N'EXEC msdb..SQLBackupTranAll02', @database_name = N'master', @server = N'', @database_user_name = N'', @subsystem = N'TSQL', @cmdexec_success_code = 0, @flags = 2, @retry_attempts = 3, @retry_interval = 1, @output_file_name = N'e:\sql\bak\SQLBackupTranAllLog.txt', @on_success_step_id = 0, @on_success_action = 1, @on_fail_step_id = 0, @on_fail_action = 2
  IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback 
  EXECUTE @ReturnCode = msdb.dbo.sp_update_job @job_id = @JobID, @start_step_id = 1 

  IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback 

  -- Add the job schedules
  EXECUTE @ReturnCode = msdb.dbo.sp_add_jobschedule @job_id = @JobID, @name = N'Every 15 Minutes', @enabled = 1, @freq_type = 4, @active_start_date = 20010817, @active_start_time = 1, @freq_interval = 1, @freq_subday_type = 4, @freq_subday_interval = 15, @freq_relative_interval = 0, @freq_recurrence_factor = 0, @active_end_date = 99991231, @active_end_time = 235959
  IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback 

  -- Add the Target Servers
  EXECUTE @ReturnCode = msdb.dbo.sp_add_jobserver @job_id = @JobID, @server_name = N'(local)' 
  IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback 

END
COMMIT TRANSACTION          
GOTO   EndSave              
QuitWithRollback:
  IF (@@TRANCOUNT > 0) ROLLBACK TRANSACTION 
EndSave: 




